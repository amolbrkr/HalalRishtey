package com.halalrishtey

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val myWebView = findViewById<WebView>(R.id.webview)
        setSupportActionBar(findViewById(R.id.my_toolbar))

        actionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#ED8D8E")))
        actionBar?.title = "Halal Rishtey"
        myWebView.settings.allowFileAccess = true
        myWebView.settings.allowContentAccess = true
        myWebView.settings.javaScriptCanOpenWindowsAutomatically = true
        myWebView.settings.javaScriptEnabled = true
        myWebView.settings.databaseEnabled = true
        myWebView.settings.setAppCacheEnabled(true)

        myWebView.loadUrl("https://halalrishtey.com/")

    }
}
